# IShift App Store listing draft

Prepared from the current repository on 2026-11-05. This is a local draft only; nothing was entered in App Store Connect.

## Traditional Chinese (Taiwan)

| Field | Draft | Length |
|---|---|---:|
| Name | `IShift` | 6 / 30 characters |
| Subtitle | `紙本班表掃描與日曆管理` | 11 / 30 characters |
| Promotional text | `拍下紙本班表，AI 協助辨識日期、班別代碼與人員列；確認後儲存，並可同步到手機日曆。` | 42 / 170 characters |
| Keywords | `輪班,排班,工時,員工,同事,休假,值班,更表,班別,月曆` | 69 / 100 UTF-8 bytes |

**Description** (261 characters):

> 把紙本班表整理成可查看、可編輯的數位行程。
>
> • 拍攝或選擇班表照片，AI 協助辨識日期、人員列與班別代碼。
> • 檢查辨識內容，修正班次後再儲存。
> • 以月曆查看每日班次、休假與人員安排。
> • 選擇同步工作日、休假日或全部班次，並設定事件標題與提醒。
> • 匯出到手機日曆時保留原始班別代號，例如 B，也可加入班別名稱或姓名。
> • 把當月班表分享成圖片，自行決定是否顯示班別時間。
> • 建立群組、邀請成員並分享班表。
>
> 辨識結果可能需要人工確認與修正。訪客模式可先查看示範資料；掃描、雲端儲存及分享功能依登入狀態與權限提供。

## English

| Field | Draft | Length |
|---|---|---:|
| Name | `IShift` | 6 / 30 characters |
| Subtitle | `Scan Shifts, Sync Calendars` | 27 / 30 characters |
| Promotional text | `Scan a paper schedule, review and correct recognized shifts, save your schedule, and sync selected shifts to your device calendar.` | 130 / 170 characters |
| Keywords | `schedule,roster,work,planner,rota,staff,timetable,OCR,days off` | 62 / 100 UTF-8 bytes |

**Description** (829 characters):

> Turn a paper work schedule into a digital schedule you can review and manage.
>
> • Take or choose a schedule photo. AI helps recognize dates, people rows, and shift codes.
> • Review and correct recognized shifts before saving.
> • See work shifts, days off, and people in a calendar.
> • Choose to sync workdays, days off, or all shifts to your device calendar, with configurable event titles and reminders.
> • Keep the original shift code, such as B, at the start of each exported event. Add the shift name or person if you want more detail.
> • Share the month as an image and choose whether to show shift times.
> • Create groups, invite members, and share schedules.
>
> Recognition results may need manual review and correction. Guest mode provides sample data. Scanning, cloud storage, and sharing depend on sign-in state and permissions.

## App Review notes draft

**English**

> IShift helps people digitize and manage paper work schedules.
>
> To explore the app, tap “Try without an account” on the welcome screen to view sample data. To test account-backed features, use the dedicated review account entered in App Store Connect’s sign-in fields; do not use a reviewer’s personal account.
>
> To test schedule recognition, open Scan, take or select a schedule photo, and continue. IShift sends the image to its OCR service, which uses Google Gemini to recognize dates, people rows, and shift codes. The user reviews and corrects the result before saving.
>
> To test device-calendar export, open Settings, find the schedule calendar section, check the destination, review the export summary, and confirm. This writes selected shifts to the chosen device calendar; a dedicated test calendar is recommended.

**繁體中文**

> IShift 協助使用者將紙本班表數位化並管理班次。
>
> 可在歡迎畫面點選「不建立帳號試用」查看示範資料。若要測試帳號雲端功能，請使用 App Store Connect 登入資訊欄位中提供的專用審查帳號，請勿使用審查人員的個人帳號。
>
> 測試班表辨識時，請開啟「掃描」，拍攝或選擇班表照片並繼續。IShift 會將圖片送至 OCR 服務，使用 Google Gemini 辨識日期、人員列與班別代碼；使用者可先檢查及修正結果，再儲存。
>
> 測試手機日曆匯出時，請前往「設定 → 班表日曆」，核對班表日曆目的地、檢查匯出摘要並確認。確認後會將選取班次寫入所選手機日曆，建議使用專用測試日曆。

## Before submission

- App Store Connect requires a public Privacy Policy URL for an iOS app. No public policy URL is present in this repository; the app contains an in-app privacy screen only. Obtain and verify the real public URL before submission. The welcome-screen Privacy Policy link currently points to the Terms screen, so that path should also be corrected before review.
- No Support URL was found in the repository. Supply the intended, working support page in App Store Connect; do not use a guessed address.
- Enter current App Review contact details and a dedicated, working demo account through App Store Connect’s separate fields. No contact details or credentials are included in this draft.
- Verify App Privacy answers against the live services and actual data handling. The in-app policy says schedule images are sent to Google Gemini and describes account, schedule, usage, and device data; this draft does not substitute for the privacy disclosures.
- Review localization, screenshots, category, age rating, pricing, and any version-specific “What’s New” text in App Store Connect before submitting.

## Repository and release evidence

- App display name and iOS bundle identifier in `apps/mobile/app.json`: `IShift`, `com.shiftsnap.app`.
- Local `HEAD` on 2026-11-05: `065e89ac8b651f7394cdd9f055697fef460c7371`; local branches `development`, `main`, `origin/main`, and `origin/development` all pointed to this commit. The two live GitHub branch tips were independently checked with ls-remote and matched.
- Latest EAS upload receipt present in the repository: iOS `1.0.0 (14)`, build `c9c02a2e-475d-4496-ac5a-413ef5d1b706`, created 2026-10-15, source commit `5d12bb5951bd3f6a1e04638179d09a020cee553a`. The receipt records successful upload to App Store Connect; Apple processing and tester availability were not independently verified in that receipt.
- On 2026-11-05 EAS independently returned Build 14 as the newest iOS store build. Apple emailed the test recipient on Oct 15 that Build 14 was available to test. App Store submission status has not been verified.

## Character limits and references

Apple currently documents a 30-character app name and subtitle, 170-character promotional text, 4,000-character description, and 100-byte keyword field. The review-notes field maximum is 4,000 characters. Keyword fields are counted in UTF-8 bytes; the table includes the encoded byte counts.

- [App information](https://developer.apple.com/help/app-store-connect/reference/app-information/app-information)
- [Platform version information](https://developer.apple.com/help/app-store-connect/reference/app-information/platform-version-information/)
- [App Store search and keyword guidance](https://developer.apple.com/app-store/search/)
- [App Review guidelines and review information](https://developer.apple.com/app-store/review/)
- [App Store review details and notes field](https://developer.apple.com/documentation/appstoreconnectapi/app-store-review-details)
